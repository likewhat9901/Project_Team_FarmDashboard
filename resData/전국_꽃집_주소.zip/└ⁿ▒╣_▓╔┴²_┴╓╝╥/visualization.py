import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import os

class CSVEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("csv파일 병합기 데모버전")
        self.df = None
        self.bad_rows = pd.DataFrame()  # 불량 행 저장용
        print("최대 4개까지 병합 가능. 문의는 카톡으로")

        # 트리뷰 + 스크롤바 설정
        self.tree = ttk.Treeview(root)
        self.tree.pack(side=tk.LEFT, expand=True, fill='both')

        vsb = ttk.Scrollbar(root, orient="vertical", command=self.tree.yview)
        vsb.pack(side=tk.LEFT, fill='y')
        self.tree.configure(yscrollcommand=vsb.set)

        # 메뉴
        menubar = tk.Menu(root)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="CSV 병합", command=self.merge_csvs)
        filemenu.add_command(label="저장", command=self.save_csv)
        filemenu.add_command(label="불량 행 저장", command=self.save_bad_rows)
        menubar.add_cascade(label="파일", menu=filemenu)
        root.config(menu=menubar)

    def normalize_columns(self, cols):
        return [c.strip() for c in cols]

    def merge_csvs(self):
        file_paths = filedialog.askopenfilenames(filetypes=[("CSV 파일", "*.csv")])
        if not file_paths or len(file_paths) > 4:
            messagebox.showerror("오류", "CSV는 1~4개까지만 선택해주세요.")
            return

        dfs = []
        base_columns = None
        self.bad_rows = pd.DataFrame()

        for path in file_paths:
            try:
                df = pd.read_csv(path, encoding="utf-8", on_bad_lines='skip')
            except UnicodeDecodeError:
                try:
                    df = pd.read_csv(path, encoding="cp949", on_bad_lines='skip')
                except Exception as e:
                    messagebox.showerror("파일 열기 실패", f"{path}\n\n{e}")
                    return

            df.columns = self.normalize_columns(df.columns)

            if base_columns is None:
                base_columns = df.columns
            else:
                # 공통 컬럼 찾기
                common_cols = list(set(base_columns).intersection(set(df.columns)))
                if not common_cols:
                    messagebox.showerror("오류", f"공통 컬럼이 없습니다:\n{path}")
                    return
                # 공통 컬럼만 남기고 재할당
                df = df[common_cols]
                self.df = self.df[common_cols] if self.df is not None else None

            dfs.append(df)

        try:
            if self.df is None:
                self.df = pd.concat(dfs, ignore_index=True, join='inner')
            else:
                self.df = pd.concat([self.df]+dfs, ignore_index=True, join='inner')
        except Exception as e:
            messagebox.showerror("병합 실패", f"병합 중 오류 발생:\n{e}")
            return

        self.show_table()

    def save_csv(self):
        if self.df is None:
            messagebox.showinfo("정보", "저장할 데이터가 없습니다.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv")
        if path:
            try:
                self.df.to_csv(path, index=False)
                messagebox.showinfo("저장됨", f"CSV가 저장되었습니다:\n{path}")
            except Exception as e:
                messagebox.showerror("저장 실패", str(e))

    def save_bad_rows(self):
        if self.bad_rows.empty:
            messagebox.showinfo("정보", "불량 행이 없습니다.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="bad_rows.csv")
        if path:
            try:
                self.bad_rows.to_csv(path, index=False)
                messagebox.showinfo("저장됨", f"불량 행이 저장되었습니다:\n{path}")
            except Exception as e:
                messagebox.showerror("저장 실패", str(e))

    def show_table(self):
        self.tree.delete(*self.tree.get_children())
        self.tree["columns"] = list(self.df.columns)
        self.tree["show"] = "headings"
        for col in self.df.columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, anchor='w')

        for _, row in self.df.iterrows():
            self.tree.insert("", "end", values=list(row))

if __name__ == "__main__":
    root = tk.Tk()
    app = CSVEditor(root)
    root.mainloop()